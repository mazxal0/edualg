Hello

<h1>
    <b>
        This project is development
    </b>
</h1>

It's my education project </br>
Now I develop the structures:
1) LinkedList
2) DoublyLinkedList
