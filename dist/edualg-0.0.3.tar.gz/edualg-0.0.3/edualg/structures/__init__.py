__version__ = "0.0.1"
__author__ = "Mazxal"
__email__ = "makwest5008@gmail.com"

__all__ = [
]